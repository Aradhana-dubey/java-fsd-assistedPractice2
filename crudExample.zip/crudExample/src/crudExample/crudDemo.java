package crudExample;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class crudDemo {

	public static void main(String[] args) {
		String filePath = "C:\\Users\\dell\\eclipse-workspace\\AssistedPractice.txt";

        // Create a file
        create(filePath);

        // Read the contents
        readFile(filePath);

        // Update the file
        updateFile(filePath, "Updated content");

        // Read the contents after update
        readFile(filePath);

        // Delete the file
        deleteFile(filePath);
    }
	 private static void create(String filePath) {
	        try {
	            
	            Path path = Paths.get(filePath);

	            if (!Files.exists(path)) {
	                Files.createFile(path);
	                System.out.println("File created successfully.");
	            } else {
	                System.out.println("File already exists.");
	            }

	        } catch (IOException e) {
	            System.err.println("Error creating file: " + e.getMessage());
	        }
	    }

	    private static void readFile(String filePath) {
	        try {
	            List<String> lines = Files.readAllLines(Paths.get(filePath));

	            System.out.println("Contents of the file:");
	            for (String line : lines) {
	                System.out.println(line);
	            }

	        } catch (IOException e) {
	            System.err.println("Error reading from file: " + e.getMessage());
	        }
	    }

	    private static void updateFile(String filePath, String content) {
	        try {
	            Files.write(Paths.get(filePath), content.getBytes());

	            System.out.println("File updated successfully.");

	        } catch (IOException e) {
	            System.err.println("Error updating file: " + e.getMessage());
	        }
	    }

	    private static void deleteFile(String filePath) {
	        try {
	            // File deleted
	            Files.delete(Paths.get(filePath));

	            System.out.println("File deleted successfully.");

	        } catch (IOException e) {
	            System.err.println("Error deleting file: " + e.getMessage());
	        }

	}

}
