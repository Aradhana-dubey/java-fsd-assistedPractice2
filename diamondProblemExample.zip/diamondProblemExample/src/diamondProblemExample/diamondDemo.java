package diamondProblemExample;

interface AnimalType {
    default void eat() {
        System.out.println("Animal is eating");
    }
}


interface Herbivore extends AnimalType {
    default void eat() {
        System.out.println("Herbivores is eating");
    }
}

interface Carnivore extends AnimalType {
    default void eat() {
        System.out.println(" Carnivores is eating");
    }
}

class Omnivore implements Herbivore, Carnivore {
    @Override
    public void eat() {
        System.out.println(" Omnivores is eating");
        Herbivore.super.eat(); 
        Carnivore.super.eat(); 
    }
}

public class diamondDemo {

	public static void main(String[] args) {
		 Omnivore omnivore = new Omnivore();
	        omnivore.eat();

	}

}
