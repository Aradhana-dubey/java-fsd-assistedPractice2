/**
 * 
 */
/**
 * 
 */
module diamondProblemExample {
}