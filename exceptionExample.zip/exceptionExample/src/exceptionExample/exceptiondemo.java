package exceptionExample;
import java.util.Scanner;

public class exceptiondemo {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("Enter a numerator:");
            int A = scanner.nextInt();

            System.out.println("Enter a denominator:");
            int B = scanner.nextInt();

            double result = A/B;
            System.out.println("Result of division: " + result);

        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero is not allowed.");

        } catch (java.util.InputMismatchException e) {
            System.out.println("Error: Please enter valid integers.");

        } catch (Exception e) {
            // Catch any other exceptions
            System.out.println("An unexpected error occurred: " + e.getMessage());

        } 

        System.out.println("Program completed.");
    }

   
}
