package oopsExample;

class Shape {
    // Encapsulation
    String color;

    // Constructor
    public Shape(String color) {
        this.color = color;
    }

    // Abstraction
    public void draw() {
        System.out.println("Drawing a shape of color: " + color);
    }
}

// Circle is a subclass of shape
class Circle extends Shape {
    private double radius;

    // Constructor
    public Circle(String color, double radius) {
        
        super(color);
        this.radius = radius;
    }

    // Polymorphism
    public void draw() {
        System.out.println("Drawing a circle of color: " + color + ", and radius: " + radius);
    }

    // Additional method specific to Circle
    public double calculatePerimeter() {
        return 2 * Math.PI * radius;
    }
}


public class oopsDemo {

	public static void main(String[] args) {
		Shape genericShape = new Shape("Red");
        Circle redCircle = new Circle("Blue", 5.0);

        // Using objects
        genericShape.draw();  
        redCircle.draw();     
        System.out.println("Perimeter of the circle: " + redCircle.calculatePerimeter());
   

	}

}
