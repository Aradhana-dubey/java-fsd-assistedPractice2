package sleepAndWaitDemo;
class SleepThread extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("SleepThread - Count: " + i);
            try {
                // Sleep for 500 milliseconds
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class WaitThread extends Thread {
    private final Object lock;

    public WaitThread(Object lock) {
        this.lock = lock;
    }

    public void run() {
        synchronized (lock) {
            System.out.println("WaitThread - Waiting for notification");
            try {
                // Wait until notified
                lock.wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("WaitThread - Notified");
        }
    }
}



public class sleepAndWait {

	public static void main(String[] args) {
		Object lock = new Object();

        // start SleepThread
        SleepThread sleepThread = new SleepThread();
        sleepThread.start();

        //start WaitThread
        WaitThread waitThread = new WaitThread(lock);
        waitThread.start();

        // Main thread sleeps for a while
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Main thread notifies the WaitThread
        synchronized (lock) {
            System.out.println("Main Thread - Notifying WaitThread");
            lock.notify();
        }
    }
}
		

	


