package synchronization;

class BankAccount {
    private int balance;

    public BankAccount(int initialBalance) {
        this.balance = initialBalance;
    }

    // Synchronized method to withdraw money
    public synchronized void withdraw(int amount) {
        if (amount > 0 && balance >= amount) {

            balance = balance-amount;
            System.out.println(Thread.currentThread().getName() + " withdrew " + amount + ". Remaining balance: " + balance);
        } else {
            System.out.println(Thread.currentThread().getName() + " cannot withdraw. Insufficient balance.");
        }
    }
}

class WithdrawAmount extends Thread {
    private BankAccount account;
    private int amount;

    public WithdrawAmount(BankAccount account, int amount) {
        this.account = account;
        this.amount = amount;
    }

    @Override
    public void run() {
        account.withdraw(amount);
    }
}


public class synchronizationdemo {

	public static void main(String[] args) {
		BankAccount account = new BankAccount(2000);
        WithdrawAmount A = new WithdrawAmount(account, 300);
        WithdrawAmount B = new WithdrawAmount(account, 500);
        WithdrawAmount C = new WithdrawAmount(account, 200);

        A.start();
        B.start();
        C.start();

	}

}
