/**
 * 
 */
/**
 * 
 */
module throwExample {
}