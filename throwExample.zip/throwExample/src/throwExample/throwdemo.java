package throwExample;
class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class throwdemo {

	public static void main(String[] args) {
		
		try {
            methodThatThrowsCheckedException();

            methodThatThrowsUncheckedException();

            methodThatThrowsCustomException();

        } catch (CustomException e) {
            // Catch the custom exception
            System.out.println("CustomException caught: " + e.getMessage());

        } catch (ArithmeticException e) {
            // Catch the  unchecked exception
            System.out.println("ArithmeticException caught: " + e.getMessage());

        } catch (Exception e) {
            // Catch other exceptions
            System.out.println("An unexpected error occurred: " + e.getMessage());

        } finally {
            System.out.println("This block is always executed.");
        }

        System.out.println("Program completed.");
    }

    private static void methodThatThrowsCheckedException() throws InterruptedException {
        System.out.println("Sleeping for 1 seconds...");
        Thread.sleep(1000);
        System.out.println("Waking up!");
    }

    private static void methodThatThrowsUncheckedException() {
        int result = 10 / 5; // ArithmeticException
    }

    private static void methodThatThrowsCustomException() throws CustomException {
        throw new CustomException("This is a custom exception.");
    
   }

  }
