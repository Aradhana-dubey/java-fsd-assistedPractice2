package tryAndCatch;

public class tryCatchdemo {

	public static void main(String[] args) {
		int A[]= new int[4];
		try {
			A[8] = 9;
		}
		catch (ArrayIndexOutOfBoundsException e) 
        {
            System.out.println("Array index is out of bounds!"); 
        }
        finally 
        {
            System.out.println("Size of Array  " + A.length);
        }


	}

}
